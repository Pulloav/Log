/* PRIVADO: no subir a un repositorio público. Copiar a js/data/drivers.js */
const DRIVERS_SEED = [
  {"id":"dr1","name":"DINO MEJIAS","ppu":"TLXJ46","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"JUAN SAN MARTIN","replacementPpu":""},
  {"id":"dr2","name":"HILARIO PALOMINO","ppu":"TLXJ45","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"CRISTIAN CORREA","replacementPpu":""},
  {"id":"dr3","name":"MANUEL ORTUYA","ppu":"TLYL45","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"LUIS JOFRE","replacementPpu":""},
  {"id":"dr4","name":"MAURICIO NUÑEZ","ppu":"TLXJ48","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"EDGARDO SAEZ","replacementPpu":""},
  {"id":"dr5","name":"RUBEN TORRES","ppu":"TLXJ49","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"JOSE RIVERO","replacementPpu":"TPHV79"},
  {"id":"dr6","name":"WALTER FERREIRA","ppu":"TLXJ47","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"MANUEL SILVA","replacementPpu":""},
  {"id":"dr7","name":"JOHN OVIEDO","ppu":"LXJC46","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"GUILLERMO VARGAS","replacementPpu":""},
  {"id":"dr8","name":"PATRICIO DIAZ","ppu":"RWTL49","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"GUILLERMO  GATICA","replacementPpu":""},
  {"id":"dr9","name":"FREDDY TOLEDO","ppu":"RWTL50","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"WALTER CONTRERAS","replacementPpu":""},
  {"id":"dr10","name":"TMT","ppu":"","code":"F07002","company":"Transportes Master Trans Ltda.","type":"Fijo","replacement":"SALMON CARCAMO","replacementPpu":""},
  {"id":"dr11","name":"MFAUNDEZ","ppu":"","code":"F06992","company":"Maria Elena Faundez Transportes E.I.R.L.","type":"Interno","replacement":"DANNY VALLE","replacementPpu":""},
  {"id":"dr12","name":"RIO IMPERIAL","ppu":"","code":"6181917","company":"Sociedad Rio Imperial Spa","type":"Interno","replacement":"CRISTIAN JERIA","replacementPpu":""},
  {"id":"dr13","name":"CORREA","ppu":"","code":"6109836","company":"Cristian Exequiel Correa Tobar","type":"Interno","replacement":"NOE ZARATE","replacementPpu":""},
  {"id":"dr14","name":"ALTAMIRA","ppu":"","code":"F07020","company":"Transportes Altamira Ltda","type":"Interno","replacement":"ALBERTO RAMIREZ","replacementPpu":""},
  {"id":"dr15","name":"","ppu":"","code":"","company":"","type":"","replacement":"WILSON FRANCO","replacementPpu":"JYRG85"},
  {"id":"dr16","name":"Q FAS","ppu":"","code":"F08937","company":"Transporte Generico","type":"Retira Cliente","replacement":"RODRIGO  LEYTON","replacementPpu":""},
  {"id":"dr17","name":"","ppu":"","code":"","company":"","type":"","replacement":"IGNACIO LIZAMA","replacementPpu":"PBFD49"}
];
